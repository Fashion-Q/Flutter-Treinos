const double defaultTileSize = 32.0;

class MultiScenarioAssets {
  static const String mapBiome1 = 'multi_scenario/tile/map_biome1.json';
  static const String mapBiome2 = 'multi_scenario/tile/map_biome2.json';
  static const String hero = 'multi_scenario/hero/hero_multi_biome.png';
}
