enum Direction { left, right, up, down, upLeft, upRight, downLeft, downRight }
