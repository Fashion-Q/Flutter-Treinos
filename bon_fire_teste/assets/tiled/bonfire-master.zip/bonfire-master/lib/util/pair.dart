///
/// Created by
///
/// ─▄▀─▄▀
/// ──▀──▀
/// █▀▀▀▀▀█▄
/// █░░░░░█─█
/// ▀▄▄▄▄▄▀▀
///
/// Rafaelbarbosatec
/// on 06/06/22
class Pair<T, A> {
  final T first;
  final A second;

  Pair(this.first, this.second);
}
