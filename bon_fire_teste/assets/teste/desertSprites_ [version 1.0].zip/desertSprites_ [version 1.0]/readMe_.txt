
thank you for using the desertSprites_...part of the fantasy_ series' of assets on itch.io!


stuff to know - character and weapon animations

- each frame is 32x32 pixels

- character animations [from top to bottom]
  - bandit_
    - spawn, idle, run, jump [idle], jump [run], land, turn, hit and death
  - orc_
    - idle, run, jump [idle], jump [run], land, turn, hit and death
  - demon_
    - spawn, idle, run, jump [idle], jump [run], land, turn, hit and death
  - devil_
    - spawn, idle, run, jump [idle], jump [run], land, turn, hit and death
  - dinosaur_
    - idle, run, jump [idle], jump [run], land, attack [idle], attack [run], turn, hit and death

- weapon animations [from top to bottom]
  - machete_ [wood, iron, gold and diamond]
    - idle & swing
  - hammer_ [wood, iron, gold and diamond]
    - idle & swing

stuff to know - dust animations

- each frame is 48x48 pixels
- each dust animation is designed to be played at the character's position [x = 0 & y = 0 relative to the player]

- dust animations [from top to bottom]
 - run, land, hit[, breath[dinosaur only]] and death



future updates - 

- upward-facing animations 
- spin animation
- more machete and hammer animations [magic!]
- satan boss sprite

...if you have any questions or requests you can contact me at analogstudios.inc@gmail.com





                                                             