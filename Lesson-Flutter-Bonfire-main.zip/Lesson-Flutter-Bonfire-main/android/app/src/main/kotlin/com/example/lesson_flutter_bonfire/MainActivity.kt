package com.example.lesson_flutter_bonfire

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
